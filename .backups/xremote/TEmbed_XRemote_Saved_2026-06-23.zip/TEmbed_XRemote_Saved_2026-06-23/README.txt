T-Embed XRemote saved working state
Date: 2026-06-23

Target device:
LilyGo T-Embed CC1101 Plus

Contains:
- Current flipper_xremote source folder
- Current working flipper_xremote.fap
- Firmware files modified for T-Embed/XRemote:
  - submenu.c
  - view_dispatcher.c
  - firmware_api.c

Current XRemote state:
- Vertical and horizontal layouts supported
- Wheel navigation enabled
- Profile routing for TV, Sound, Fan, and Heater
- Original XRemote raised Button_18x18 bitmap style
- Custom bitmap icon assets in XRemote/assets
- FAP build completed with all 153 symbols resolved

Build commands:
source ~/esp/esp-idf/export.sh
./buildAndFlash_T-Embed.sh --port /dev/cu.usbmodem2101
./buildFap.sh applications_user/flipper_xremote
