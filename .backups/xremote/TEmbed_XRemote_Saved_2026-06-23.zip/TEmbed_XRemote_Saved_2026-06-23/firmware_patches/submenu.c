#include "submenu.h"

#include <assets_icons.h>
#include "../elements.h"
#include <furi.h>
#include <m-array.h>

struct Submenu {
    View* view;

    FuriTimer* locked_timer;
};

typedef struct {
    FuriString* label;
    uint32_t index;
    union {
        SubmenuItemCallback callback;
        SubmenuItemCallbackEx callback_ex;
    };
    void* callback_context;
    bool has_extended_events;

    bool locked;
    bool is_separator;
    bool centered;
    FuriString* locked_message;
} SubmenuItem;

static void SubmenuItem_init(SubmenuItem* item) {
    item->label = furi_string_alloc();
    item->index = 0;
    item->callback = NULL;
    item->callback_context = NULL;
    item->locked = false;
    item->is_separator = false;
    item->centered = false;
    item->locked_message = furi_string_alloc();
}

static void SubmenuItem_init_set(SubmenuItem* item, const SubmenuItem* src) {
    item->label = furi_string_alloc_set(src->label);
    item->index = src->index;
    item->callback = src->callback;
    item->callback_context = src->callback_context;
    item->locked = src->locked;
    item->is_separator = src->is_separator;
    item->centered = src->centered;
    item->locked_message = furi_string_alloc_set(src->locked_message);
}

static void SubmenuItem_set(SubmenuItem* item, const SubmenuItem* src) {
    furi_string_set(item->label, src->label);
    item->index = src->index;
    item->callback = src->callback;
    item->callback_context = src->callback_context;
    item->locked = src->locked;
    item->is_separator = src->is_separator;
    item->centered = src->centered;
    furi_string_set(item->locked_message, src->locked_message);
}

static void SubmenuItem_clear(SubmenuItem* item) {
    furi_string_free(item->label);
    furi_string_free(item->locked_message);
}

ARRAY_DEF(
    SubmenuItemArray,
    SubmenuItem,
    (INIT(API_2(SubmenuItem_init)),
     SET(API_6(SubmenuItem_set)),
     INIT_SET(API_6(SubmenuItem_init_set)),
     CLEAR(API_2(SubmenuItem_clear))))

typedef struct {
    SubmenuItemArray_t items;
    FuriString* header;
    size_t position;
    size_t window_position;

    bool locked_message_visible;
    bool is_vertical;
    bool header_centered;
} SubmenuModel;

static void submenu_process_up(Submenu* submenu);
static void submenu_process_down(Submenu* submenu);
static void submenu_process_ok(Submenu* submenu, InputType input_type);

static size_t submenu_items_on_screen(SubmenuModel* model) {
    size_t res = (model->is_vertical) ? 10 : 4;
    return (furi_string_empty(model->header)) ? res : res - 1;
}

static void submenu_view_draw_callback(Canvas* canvas, void* _model) {
    SubmenuModel* model = _model;

    const uint8_t item_height = model->is_vertical ? 12 : 16;
    uint8_t item_width = canvas_width(canvas) - 5;

    canvas_clear(canvas);

    if(!furi_string_empty(model->header)) {
        canvas_set_font(canvas, FontPrimary);
        if(model->header_centered) {
            canvas_draw_str_aligned(
                canvas,
                canvas_width(canvas) / 2,
                11,
                AlignCenter,
                AlignBottom,
                furi_string_get_cstr(model->header));
        } else {
            canvas_draw_str(canvas, 4, 11, furi_string_get_cstr(model->header));
        }
    }

    canvas_set_font(canvas, FontSecondary);

    size_t position = 0;
    SubmenuItemArray_it_t it;
    for(SubmenuItemArray_it(it, model->items); !SubmenuItemArray_end_p(it);
        SubmenuItemArray_next(it)) {
        const size_t item_position = position - model->window_position;
        const size_t items_on_screen = submenu_items_on_screen(model);
        uint8_t y_offset = furi_string_empty(model->header) ? 0 : item_height;
        bool is_locked = SubmenuItemArray_cref(it)->locked;

        if(item_position < items_on_screen) {
            if(SubmenuItemArray_cref(it)->is_separator) {
                // Schmale horizontale Linie quer durch die Item-Zeile.
                canvas_set_color(canvas, ColorBlack);
                uint8_t cy = y_offset + (item_position * item_height) + item_height / 2;
                canvas_draw_line(canvas, 4, cy, item_width - 4, cy);
                position++;
                continue;
            }

            if(position == model->position) {
                canvas_set_color(canvas, ColorBlack);
                elements_slightly_rounded_box(
                    canvas,
                    0,
                    y_offset + (item_position * item_height) + 1,
                    item_width,
                    item_height - 2);
                canvas_set_color(canvas, ColorWhite);
            } else {
                canvas_set_color(canvas, ColorBlack);
            }

            if(is_locked) {
                canvas_draw_icon(
                    canvas,
                    item_width - 10,
                    y_offset + (item_position * item_height) + item_height - 12,
                    &I_Lock_7x8);
            }

            FuriString* disp_str = furi_string_alloc_set(SubmenuItemArray_cref(it)->label);
            elements_string_fit_width(canvas, disp_str, item_width - (is_locked ? 21 : 11));

            if(SubmenuItemArray_cref(it)->centered) {
                canvas_draw_str_aligned(
                    canvas,
                    item_width / 2,
                    y_offset + (item_position * item_height) + item_height - 4,
                    AlignCenter,
                    AlignBottom,
                    furi_string_get_cstr(disp_str));
            } else {
                canvas_draw_str(
                    canvas,
                    6,
                    y_offset + (item_position * item_height) + item_height - 4,
                    furi_string_get_cstr(disp_str));
            }

            furi_string_free(disp_str);
        }

        position++;
    }

    elements_scrollbar(canvas, model->position, SubmenuItemArray_size(model->items));

    if(model->locked_message_visible) {
        const uint8_t frame_x = 7;
        const uint8_t frame_width = canvas_width(canvas) - frame_x * 2;
        const uint8_t frame_y = 7;
        const uint8_t frame_height = canvas_height(canvas) - frame_y * 2;

        canvas_set_color(canvas, ColorWhite);
        canvas_draw_box(canvas, frame_x + 2, frame_y + 2, frame_width - 4, frame_height - 4);

        canvas_set_color(canvas, ColorBlack);
        canvas_draw_icon(
            canvas, frame_x + 2, canvas_height(canvas) - frame_y - 2 - 42, &I_WarningDolphin_45x42);

        canvas_draw_rframe(canvas, frame_x, frame_y, frame_width, frame_height, 3);
        canvas_draw_rframe(canvas, frame_x + 1, frame_y + 1, frame_width - 2, frame_height - 2, 2);
        elements_multiline_text_aligned(
            canvas,
            (model->is_vertical) ? 32 : 84,
            (model->is_vertical) ? 42 : 32,
            AlignCenter,
            AlignCenter,
            furi_string_get_cstr(
                SubmenuItemArray_get(model->items, model->position)->locked_message));
    }
}

static bool submenu_view_input_callback(InputEvent* event, void* context) {
    Submenu* submenu = context;
    furi_assert(submenu);
    bool consumed = false;

    bool locked_message_visible = false;
    with_view_model(
        submenu->view,
        SubmenuModel * model,
        { locked_message_visible = model->locked_message_visible; },
        false);

    if(locked_message_visible && (event->type == InputTypeShort || event->type == InputTypeLong)) {
        with_view_model(
            submenu->view, SubmenuModel * model, { model->locked_message_visible = false; }, true);
        consumed = true;
    } else if(event->key == InputKeyOk) {
        consumed = true;
        submenu_process_ok(submenu, event->type);
    } else if(event->type == InputTypeShort) {
        switch(event->key) {
        case InputKeyUp:
            consumed = true;
            submenu_process_up(submenu);
            break;
        case InputKeyDown:
            consumed = true;
            submenu_process_down(submenu);
            break;
        default:
            break;
        }
    } else if(event->type == InputTypeRepeat) {
        if(event->key == InputKeyUp) {
            consumed = true;
            submenu_process_up(submenu);
        } else if(event->key == InputKeyDown) {
            consumed = true;
            submenu_process_down(submenu);
        }
    }

    return consumed;
}

void submenu_timer_callback(void* context) {
    furi_assert(context);
    Submenu* submenu = context;

    with_view_model(
        submenu->view, SubmenuModel * model, { model->locked_message_visible = false; }, true);
}

Submenu* submenu_alloc(void) {
    Submenu* submenu = malloc(sizeof(Submenu));
    submenu->view = view_alloc();
    view_set_context(submenu->view, submenu);
    view_allocate_model(submenu->view, ViewModelTypeLocking, sizeof(SubmenuModel));
    view_set_draw_callback(submenu->view, submenu_view_draw_callback);
    view_set_input_callback(submenu->view, submenu_view_input_callback);

    submenu->locked_timer = furi_timer_alloc(submenu_timer_callback, FuriTimerTypeOnce, submenu);

    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            SubmenuItemArray_init(model->items);
            model->position = 0;
            model->window_position = 0;
            model->header = furi_string_alloc();
        },
        true);

    return submenu;
}

void submenu_free(Submenu* submenu) {
    furi_check(submenu);

    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            furi_string_free(model->header);
            SubmenuItemArray_clear(model->items);
        },
        true);
    furi_timer_stop(submenu->locked_timer);
    furi_timer_free(submenu->locked_timer);
    view_free(submenu->view);
    free(submenu);
}

View* submenu_get_view(Submenu* submenu) {
    furi_check(submenu);
    return submenu->view;
}

void submenu_add_item(
    Submenu* submenu,
    const char* label,
    uint32_t index,
    SubmenuItemCallback callback,
    void* callback_context) {
    submenu_add_lockable_item(submenu, label, index, callback, callback_context, false, NULL);
}

void submenu_add_item_centered(
    Submenu* submenu,
    const char* label,
    uint32_t index,
    SubmenuItemCallback callback,
    void* callback_context) {
    SubmenuItem* item = NULL;
    furi_check(label);
    furi_check(submenu);

    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            item = SubmenuItemArray_push_new(model->items);
            furi_string_set_str(item->label, label);
            item->index = index;
            item->callback = callback;
            item->callback_context = callback_context;
            item->has_extended_events = false;
            item->locked = false;
            item->centered = true;
        },
        true);
}

void submenu_add_lockable_item(
    Submenu* submenu,
    const char* label,
    uint32_t index,
    SubmenuItemCallback callback,
    void* callback_context,
    bool locked,
    const char* locked_message) {
    SubmenuItem* item = NULL;
    furi_check(label);
    furi_check(submenu);
    if(locked) {
        furi_check(locked_message);
    }

    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            item = SubmenuItemArray_push_new(model->items);
            furi_string_set_str(item->label, label);
            item->index = index;
            item->callback = callback;
            item->callback_context = callback_context;
            item->has_extended_events = false;
            item->locked = locked;
            if(locked) {
                furi_string_set_str(item->locked_message, locked_message);
            }
        },
        true);
}

void submenu_add_item_ex(
    Submenu* submenu,
    const char* label,
    uint32_t index,
    SubmenuItemCallbackEx callback,
    void* callback_context) {
    SubmenuItem* item = NULL;
    furi_check(label);
    furi_check(submenu);

    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            item = SubmenuItemArray_push_new(model->items);
            furi_string_set_str(item->label, label);
            item->index = index;
            item->callback_ex = callback;
            item->callback_context = callback_context;
            item->has_extended_events = true;
        },
        true);
}

void submenu_add_separator(Submenu* submenu) {
    furi_check(submenu);

    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            SubmenuItem* item = SubmenuItemArray_push_new(model->items);
            item->is_separator = true;
            item->callback = NULL;
            item->callback_context = NULL;
            item->has_extended_events = false;
            item->locked = false;
        },
        true);
}

void submenu_change_item_label(Submenu* submenu, uint32_t index, const char* label) {
    furi_check(submenu);
    furi_check(label);

    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            SubmenuItemArray_it_t it;
            for(SubmenuItemArray_it(it, model->items); !SubmenuItemArray_end_p(it);
                SubmenuItemArray_next(it)) {
                if(index == SubmenuItemArray_cref(it)->index) {
                    furi_string_set_str(SubmenuItemArray_cref(it)->label, label);
                    break;
                }
            }
        },
        true);
}

void submenu_remove_item(Submenu* submenu, uint32_t index) {
    furi_check(submenu);

    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            SubmenuItemArray_it_t it;
            for(SubmenuItemArray_it(it, model->items); !SubmenuItemArray_end_p(it);
                SubmenuItemArray_next(it)) {
                if(index == SubmenuItemArray_cref(it)->index) {
                    SubmenuItemArray_remove(model->items, it);
                    break;
                }
            }
        },
        true);
}

void submenu_reset(Submenu* submenu) {
    furi_check(submenu);
    view_set_orientation(submenu->view, ViewOrientationHorizontal);

    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            SubmenuItemArray_reset(model->items);
            model->position = 0;
            model->window_position = 0;
            model->is_vertical = false;
            furi_string_reset(model->header);
        },
        true);
}

uint32_t submenu_get_selected_item(Submenu* submenu) {
    furi_check(submenu);

    uint32_t selected_item_index = 0;

    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            if(model->position < SubmenuItemArray_size(model->items)) {
                const SubmenuItem* item = SubmenuItemArray_cget(model->items, model->position);
                selected_item_index = item->index;
            }
        },
        false);

    return selected_item_index;
}

void submenu_set_selected_item(Submenu* submenu, uint32_t index) {
    furi_check(submenu);
    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            size_t position = 0;
            SubmenuItemArray_it_t it;
            for(SubmenuItemArray_it(it, model->items); !SubmenuItemArray_end_p(it);
                SubmenuItemArray_next(it)) {
                if(index == SubmenuItemArray_cref(it)->index) {
                    break;
                }
                position++;
            }

            const size_t items_size = SubmenuItemArray_size(model->items);

            if(position >= items_size) {
                position = 0;
            }

            model->position = position;
            model->window_position = position;

            if(model->window_position > 0) {
                model->window_position -= 1;
            }

            const size_t items_on_screen = submenu_items_on_screen(model);

            if(items_size <= items_on_screen) {
                model->window_position = 0;
            } else {
                const size_t pos = items_size - items_on_screen;
                if(model->window_position > pos) {
                    model->window_position = pos;
                }
            }
        },
        true);
}

static bool submenu_item_at_is_separator(SubmenuModel* model, size_t pos) {
    if(pos >= SubmenuItemArray_size(model->items)) return false;
    return SubmenuItemArray_cget(model->items, pos)->is_separator;
}

void submenu_process_up(Submenu* submenu) {
    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            const size_t items_on_screen = submenu_items_on_screen(model);
            const size_t items_size = SubmenuItemArray_size(model->items);

            // Mindestens einmal nach oben bewegen, dann eventuelle Separators
            // überspringen. Bei Wraparound von oben nach unten dasselbe.
            for(size_t step = 0; step < items_size; ++step) {
                if(model->position > 0) {
                    model->position--;
                    if((model->position == model->window_position) &&
                       (model->window_position > 0)) {
                        model->window_position--;
                    }
                } else {
                    model->position = items_size - 1;
                    if(model->position > items_on_screen - 1) {
                        model->window_position = model->position - (items_on_screen - 1);
                    } else {
                        model->window_position = 0;
                    }
                }
                if(!submenu_item_at_is_separator(model, model->position)) break;
            }
        },
        true);
}

void submenu_process_down(Submenu* submenu) {
    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            const size_t items_on_screen = submenu_items_on_screen(model);
            const size_t items_size = SubmenuItemArray_size(model->items);

            for(size_t step = 0; step < items_size; ++step) {
                if(model->position < items_size - 1) {
                    model->position++;
                    if((model->position - model->window_position > items_on_screen - 2) &&
                       (model->window_position < items_size - items_on_screen)) {
                        model->window_position++;
                    }
                } else {
                    model->position = 0;
                    model->window_position = 0;
                }
                if(!submenu_item_at_is_separator(model, model->position)) break;
            }
        },
        true);
}

void submenu_process_ok(Submenu* submenu, InputType input_type) {
    SubmenuItem* item = NULL;

    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            const size_t items_size = SubmenuItemArray_size(model->items);
            if(model->position < items_size) {
                item = SubmenuItemArray_get(model->items, model->position);
            }
            if(item && item->locked &&
               (input_type == InputTypeShort || input_type == InputTypeLong)) {
                model->locked_message_visible = true;
                furi_timer_start(submenu->locked_timer, furi_kernel_get_tick_frequency() * 3);
            }
        },
        true);

    if(!item) return;
    if(item->is_separator) return;
    if(item->locked) {
        return;
    }

    if(!item->has_extended_events && input_type == InputTypeShort && item->callback) {
        item->callback(item->callback_context, item->index);
    } else if(item->has_extended_events && item->callback_ex) {
        item->callback_ex(item->callback_context, input_type, item->index);
    }
}

void submenu_set_header(Submenu* submenu, const char* header) {
    furi_check(submenu);

    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            if(header == NULL) {
                furi_string_reset(model->header);
            } else {
                furi_string_set_str(model->header, header);
            }
            model->header_centered = false;
        },
        true);
}

void submenu_set_header_centered(Submenu* submenu, const char* header) {
    furi_check(submenu);

    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            if(header == NULL) {
                furi_string_reset(model->header);
            } else {
                furi_string_set_str(model->header, header);
            }
            model->header_centered = true;
        },
        true);
}

void submenu_set_orientation(Submenu* submenu, ViewOrientation orientation) {
    furi_check(submenu);
    const bool is_vertical = orientation == ViewOrientationVertical ||
                             orientation == ViewOrientationVerticalFlip;

    view_set_orientation(submenu->view, orientation);

    with_view_model(
        submenu->view,
        SubmenuModel * model,
        {
            model->is_vertical = is_vertical;

            // Recalculating the position
            // Need if _set_orientation is called after _set_selected_item
            size_t position = model->position;
            const size_t items_size = SubmenuItemArray_size(model->items);
            const size_t items_on_screen = submenu_items_on_screen(model);

            if(position >= items_size) {
                position = 0;
            }

            model->position = position;
            model->window_position = position;

            if(model->window_position > 0) {
                model->window_position -= 1;
            }

            if(items_size <= items_on_screen) {
                model->window_position = 0;
            } else {
                const size_t pos = items_size - items_on_screen;
                if(model->window_position > pos) {
                    model->window_position = pos;
                }
            }
        },
        true);
}
